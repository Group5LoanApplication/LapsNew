package com.cg.laps.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.laps.dto.LoanProgramsOffered;
import com.cg.laps.exception.LoanException;
import com.cg.laps.service.LoanService;
import com.cg.laps.service.LoanServiceImpl;

/**
 * Servlet implementation class LoanController
 */
@WebServlet(urlPatterns = { "/LoanController" })
public class LoanController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	LoanService loanService;

	public LoanController() {
		super();
		loanService = new LoanServiceImpl();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = null;
		String path = request.getServletPath();
		String url = "";

		switch (path) {
		case "/LoanController":
			System.out.println("LoanController");

			List<LoanProgramsOffered> programlist;
			try {
				programlist = loanService.viewLoanProgramsOffered();
				request.setAttribute("program", programlist);
				dispatcher = request.getRequestDispatcher("LoanProgram.jsp");
				dispatcher.forward(request, response);
			} catch (LoanException e) {
				dispatcher = request.getRequestDispatcher("LoanError.jsp");
				request.setAttribute("exception", e);
				dispatcher.forward(request, response);
			}

			break;

		default:
			break;

		}

	}
}
